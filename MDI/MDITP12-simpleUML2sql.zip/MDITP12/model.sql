-- <br>
-- Uncomment me if you want :)
-- CREATE DATABASE model;

CREATE TABLE B2
(

);

CREATE TABLE A
(
    attA String NOT NULL
);

CREATE TABLE B
(
    attB Integer NOT NULL
);

CREATE TABLE Y
(
    attY String NOT NULL
);

CREATE TABLE C2
(

);

CREATE TABLE C3
(

);

CREATE TABLE P2A3
(
    d Integer NOT NULL
);

CREATE TABLE A2
(

);

CREATE TABLE Z
(

);

CREATE TABLE B
(

);

CREATE TABLE C
(
    attC1 Integer NOT NULL,
    attC2 Boolean NOT NULL
);

CREATE TABLE P2A2
(
    b Boolean NOT NULL,
    d Integer NOT NULL
);

CREATE TABLE R
(

);

